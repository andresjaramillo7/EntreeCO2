﻿using Npgsql;
using System.Data;

public class Connection
{
    NpgsqlConnection conn = new NpgsqlConnection();
    string cadena = "server=localhost;port=5432;user id=postgres;password=AndresDev77.;database=EntreeCO2;";

    public NpgsqlConnection OpenConexion()
    {
        try
        {
            conn.ConnectionString = cadena;
            conn.Open();
        }
        catch (NpgsqlException e)
        {
            Console.WriteLine($"Error al abrir la conexión: {e.Message}");
            throw;
        }
        return conn;
    }

    public void CloseConexion()
    {
        try
        {
            if (conn != null && conn.State == ConnectionState.Open)
                conn.Close();
        }
        catch (NpgsqlException e)
        {
            Console.WriteLine($"Error al cerrar la conexión: {e.Message}");
            throw;
        }
    }
}
