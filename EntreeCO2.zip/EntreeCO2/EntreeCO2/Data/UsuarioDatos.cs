﻿using Npgsql;
using EntreeCO2.Models;
using System.Data;

namespace EntreeCO2.Data
{
    public class UsuarioDatos
    {
        private readonly Connection _connection;

        public UsuarioDatos()
        {
            _connection = new Connection();
        }
        public UsuarioModel ObtenerUsuario(int idUsuario)
        {
            UsuarioModel usuario = null;
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("SELECT * FROM Usuarios WHERE id_usuario = @IdUsuario", con);
                cmd.Parameters.AddWithValue("@IdUsuario", idUsuario);

                using (var dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        usuario = new UsuarioModel
                        {
                            IdUsuario = Convert.ToInt32(dr["id_usuario"]),
                            NombreUsuario = dr["nombre_usuario"].ToString(),
                            Email = dr["email"].ToString(),
                            Contraseña = dr["contraseña"].ToString(),
                            TipoUsuario = dr["tipo_usuario"].ToString(),
                            IdRestaurante = dr.IsDBNull(dr.GetOrdinal("id_restaurante")) ? null : (int?)dr["id_restaurante"]
                        };
                    }
                }
            }
            _connection.CloseConexion();
            return usuario;
        }

        public void CrearUsuario(UsuarioModel usuario)
        {
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("INSERT INTO Usuarios (nombre_usuario, email, contraseña, tipo_usuario, id_restaurante) VALUES (@NombreUsuario, @Email, @Contraseña, @TipoUsuario, @IdRestaurante)", con);
                cmd.Parameters.AddWithValue("@NombreUsuario", usuario.NombreUsuario);
                cmd.Parameters.AddWithValue("@Email", usuario.Email);
                cmd.Parameters.AddWithValue("@Contraseña", usuario.Contraseña);
                cmd.Parameters.AddWithValue("@TipoUsuario", usuario.TipoUsuario);
                cmd.Parameters.AddWithValue("@IdRestaurante", usuario.IdRestaurante ?? (object)DBNull.Value);

                cmd.ExecuteNonQuery();
            }
            _connection.CloseConexion();
        }


        public bool ValidarUsuario(string email, string contraseña)
        {
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("SELECT contraseña FROM Usuarios WHERE email = @Email AND contraseña = @Contraseña", con);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Contraseña", contraseña);

                using (var dr = cmd.ExecuteReader())
                {
                    bool isValid = dr.Read();
                    _connection.CloseConexion();
                    return isValid;
                }
            }
        }
    }
}