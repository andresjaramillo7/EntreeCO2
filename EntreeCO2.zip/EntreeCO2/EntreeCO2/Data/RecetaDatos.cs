﻿using EntreeCO2.Models;
using Npgsql;
using System.Data.Common;

namespace EntreeCO2.Data
{
    public class RecetaDatos
    {
        private readonly Connection _connection;

        public RecetaDatos(Connection connection)
        {
            _connection = connection;
        }

        public List<RecetaModel> ListarRecetas()
        {
            List<RecetaModel> recetas = new List<RecetaModel>();
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("SELECT * FROM Recetas", con);
                using (var dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        var receta = new RecetaModel
                        {
                            IdReceta = dr.GetInt32(dr.GetOrdinal("id_receta")),
                            NombreReceta = dr.GetString(dr.GetOrdinal("nombre_receta")),
                            MetodoPreparacion = dr.GetString(dr.GetOrdinal("metodo_preparacion")),
                            IdRestaurante = dr.GetInt32(dr.GetOrdinal("id_restaurante"))
                        };
                        recetas.Add(receta);
                    }
                }
                _connection.CloseConexion();
            }
            return recetas;
        }

        public void InsertarReceta(string nombreReceta, string metodoPreparacion, int idRestaurante)
        {
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("CALL InsertarReceta(@_nombre_receta, @_metodo_preparacion, @_id_restaurante)", con);
                cmd.Parameters.AddWithValue("@_nombre_receta", nombreReceta);
                cmd.Parameters.AddWithValue("@_metodo_preparacion", metodoPreparacion);
                cmd.Parameters.AddWithValue("@_id_restaurante", idRestaurante);

                cmd.ExecuteNonQuery();
            }
        }
        public void ActualizarReceta(RecetaModel receta)
        {
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("CALL ActualizarReceta(@IdReceta, @NombreReceta, @MetodoPreparacion, @IdRestaurante)", con);
                cmd.Parameters.AddWithValue("@IdReceta", receta.IdReceta);
                cmd.Parameters.AddWithValue("@NombreReceta", receta.NombreReceta);
                cmd.Parameters.AddWithValue("@MetodoPreparacion", receta.MetodoPreparacion);
                cmd.Parameters.AddWithValue("@IdRestaurante", receta.IdRestaurante);
                cmd.ExecuteNonQuery();
                _connection.CloseConexion();
            }
        }
        public void EliminarReceta(int idReceta)
        {
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("CALL EliminarReceta(@IdReceta)", con);
                cmd.Parameters.AddWithValue("@IdReceta", idReceta);
                cmd.ExecuteNonQuery();
                _connection.CloseConexion();
            }
        }
        public RecetaModel ObtenerReceta(int idReceta)
        {
            RecetaModel receta = null;
            try
            {
                using (var con = _connection.OpenConexion())
                {
                    var cmd = new NpgsqlCommand("SELECT * FROM Recetas WHERE id_receta = @IdReceta", con);
                    cmd.Parameters.AddWithValue("@IdReceta", idReceta);

                    using (var dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            receta = new RecetaModel
                            {
                                IdReceta = dr.GetInt32(dr.GetOrdinal("id_receta")),
                                NombreReceta = dr.GetString(dr.GetOrdinal("nombre_receta")),
                                MetodoPreparacion = dr.GetString(dr.GetOrdinal("metodo_preparacion")),
                                IdRestaurante = dr.GetInt32(dr.GetOrdinal("id_restaurante"))
                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            finally
            {
                _connection.CloseConexion();
            }
            return receta;
        }
    }
}