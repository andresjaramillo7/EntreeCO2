﻿using EntreeCO2.Models;
using Npgsql;

namespace EntreeCO2.Data
{
    public class IngredienteDatos
    {
        private readonly Connection _connection;

        public IngredienteDatos()
        {
            _connection = new Connection();
        }

        public void InsertarIngrediente(string nombre, decimal pesoCarbono)
        {
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("CALL InsertarIngrediente(@Nombre, @PesoCarbono)", con);
                cmd.Parameters.AddWithValue("@Nombre", nombre);
                cmd.Parameters.AddWithValue("@PesoCarbono", pesoCarbono);
                cmd.ExecuteNonQuery();
            }
            _connection.CloseConexion();
        }
        public void ActualizarIngrediente(int idIngrediente, string nombre, decimal pesoCarbono)
        {
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("CALL ActualizarIngrediente(@IdIngrediente, @Nombre, @PesoCarbono)", con);
                cmd.Parameters.AddWithValue("@IdIngrediente", idIngrediente);
                cmd.Parameters.AddWithValue("@Nombre", nombre);
                cmd.Parameters.AddWithValue("@PesoCarbono", pesoCarbono);
                cmd.ExecuteNonQuery();
            }
            _connection.CloseConexion();
        }
        public void EliminarIngrediente(int idIngrediente)
        {
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("CALL EliminarIngrediente(@IdIngrediente)", con); 
                cmd.Parameters.AddWithValue("@IdIngrediente", idIngrediente);
                cmd.ExecuteNonQuery();
            }
            _connection.CloseConexion();
        }
        public List<IngredienteModel> ListarIngredientes()
        {
            List<IngredienteModel> ingredientes = new List<IngredienteModel>();

            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("SELECT * FROM Ingredientes", con);

                using (var dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ingredientes.Add(new IngredienteModel
                        {
                            IdIngrediente = Convert.ToInt32(dr["id_ingrediente"]),
                            Nombre = dr["nombre"].ToString(),
                            PesoCarbono = Convert.ToDecimal(dr["peso_carbono"])
                        });
                    }
                }
            }
            _connection.CloseConexion();
            return ingredientes;
        }
        public IngredienteModel ObtenerIngrediente(int id)
        {
            IngredienteModel ingrediente = null;

            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("SELECT * FROM Ingredientes WHERE id_ingrediente = @Id", con);
                cmd.Parameters.AddWithValue("@Id", id);

                using (var dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        ingrediente = new IngredienteModel
                        {
                            IdIngrediente = dr.GetInt32(dr.GetOrdinal("id_ingrediente")),
                            Nombre = dr.GetString(dr.GetOrdinal("nombre")),
                            PesoCarbono = dr.GetDecimal(dr.GetOrdinal("peso_carbono"))
                        };
                    }
                }
            }
            _connection.CloseConexion();
            return ingrediente;
        }
        public List<IngredienteModel> GetIngredientesPorReceta(int idReceta)
        {
            var ingredientes = new List<IngredienteModel>();

            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("SELECT * FROM get_ingredientes_carbono2(@IdReceta)", con);
                cmd.Parameters.AddWithValue("@IdReceta", idReceta);

                using (var dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        var ingrediente = new IngredienteModel
                        {
                            IdIngrediente = Convert.ToInt32(dr["id_ingrediente"]),
                            Nombre = dr["nombre_ingrediente"].ToString(),
                            PesoCarbono = Convert.ToDecimal(dr["peso_carbono"])
                        };
                        ingredientes.Add(ingrediente);
                    }
                }
            }

            return ingredientes;
        }
        public void InsertarIngredienteEnReceta(int idReceta, int idIngrediente)
        {
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("CALL InsertarRecetaIngrediente(@IdReceta, @IdIngrediente)", con);
                cmd.Parameters.AddWithValue("@IdReceta", idReceta);
                cmd.Parameters.AddWithValue("@IdIngrediente", idIngrediente);
                cmd.ExecuteNonQuery();
                _connection.CloseConexion();
            }
        }
        public void EliminarIngredienteDeReceta(int idIngrediente, int idReceta)
        {
            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("CALL EliminarIngredienteDeReceta(@IdIngrediente, @IdReceta)", con);
                cmd.Parameters.AddWithValue("@IdIngrediente", idIngrediente);
                cmd.Parameters.AddWithValue("@IdReceta", idReceta);
                cmd.ExecuteNonQuery();
                _connection.CloseConexion();
            }
        }
        public List<IngredienteModel> ListarTodosLosIngredientes()
        {
            var ingredientes = new List<IngredienteModel>();

            using (var con = _connection.OpenConexion())
            {
                var cmd = new NpgsqlCommand("SELECT id_ingrediente, nombre, peso_carbono FROM Ingredientes", con);
                using (var dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ingredientes.Add(new IngredienteModel
                        {
                            IdIngrediente = dr.GetInt32(dr.GetOrdinal("id_ingrediente")),
                            Nombre = dr.GetString(dr.GetOrdinal("nombre")),
                            PesoCarbono = dr.GetDecimal(dr.GetOrdinal("peso_carbono"))
                        });
                    }
                }
                _connection.CloseConexion();
            }
            return ingredientes;
        }
    }
}
