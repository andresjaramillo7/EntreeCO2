﻿using EntreeCO2.Data;
using EntreeCO2.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EntreeCO2.Controllers
{
    [Route("[controller]/[action]")]
    public class IngredientesController : Controller
    {
        private readonly IngredienteDatos _ingredienteDatos;

        public IngredientesController(IngredienteDatos ingredienteDatos)
        {
            _ingredienteDatos = ingredienteDatos;
        }

        public IActionResult Index()
        {
            var ingredientes = _ingredienteDatos.ListarIngredientes();
            return View(ingredientes);
        }

        [HttpGet("{id}")]
        public IActionResult Edit(int id)
        {
            var ingrediente = _ingredienteDatos.ObtenerIngrediente(id);
            if (ingrediente == null)
            {
                TempData["ErrorMessage"] = "Ingrediente no encontrado.";
                return RedirectToAction("Index");
            }
            return View(ingrediente);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit2(IngredienteModel ingrediente)
        {
            if (!ModelState.IsValid)
            {
                return View(ingrediente);
            }
            try
            {
                _ingredienteDatos.ActualizarIngrediente(ingrediente.IdIngrediente, ingrediente.Nombre, ingrediente.PesoCarbono);
                TempData["SuccessMessage"] = "Ingrediente actualizado exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error al actualizar el ingrediente. Detalles: {ex.Message}";
            }
            return RedirectToAction("Index");
        }

        [HttpGet("{id}")]
        public IActionResult Delete(int id)
        {
            var ingrediente = _ingredienteDatos.ObtenerIngrediente(id);
            if (ingrediente == null)
            {
                TempData["ErrorMessage"] = "Ingrediente no encontrado.";
                return RedirectToAction("Index");
            }
            return View(ingrediente);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                _ingredienteDatos.EliminarIngrediente(id);
                TempData["SuccessMessage"] = "Ingrediente eliminado exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error al eliminar el ingrediente. Detalles: {ex.Message}";
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult<List<IngredienteModel>> Get()
        {
            return _ingredienteDatos.ListarIngredientes();
        }

        [HttpGet("Add")]
        public IActionResult Add()
        {
            return View(new IngredienteModel());
        }

        [HttpPost]
        public IActionResult Add2([FromForm] IngredienteModel ingrediente)
        {
            try
            {
                _ingredienteDatos.InsertarIngrediente(ingrediente.Nombre, ingrediente.PesoCarbono);
                TempData["SuccessMessage"] = "Ingrediente agregado exitosamente.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error al agregar el ingrediente. Detalles: {ex.Message}";
                return RedirectToAction("Index");
            }
        }
        [HttpGet("ViewByReceta/{id}")]
        public IActionResult ViewByReceta(int id)
        {
            var ingredientes = _ingredienteDatos.GetIngredientesPorReceta(id);

            ViewBag.IdReceta = id;

            if (ingredientes == null || !ingredientes.Any())
            {
                ingredientes = new List<IngredienteModel>();
                TempData["InfoMessage"] = "Esta receta aún no tiene ingredientes. Puedes añadir nuevos ingredientes.";
            }

            return View(ingredientes);
        }
        public IActionResult AddViewByReceta(int idReceta)
        {
            ViewBag.Ingredientes = new SelectList(_ingredienteDatos.ListarTodosLosIngredientes(), "IdIngrediente", "Nombre");
            var model = new RecetaIngredienteModel { IdReceta = idReceta };
            return View(model);
        }

        public IActionResult DeleteViewByReceta(int idReceta, int idIngrediente)
        {
            var model = new RecetaIngredienteModel { IdReceta = idReceta, IdIngrediente = idIngrediente };
            return View(model);
        }

        [HttpPost]
        public IActionResult AgregarIngredienteAReceta(int idReceta, int idIngrediente)
        {
            try
            {
                _ingredienteDatos.InsertarIngredienteEnReceta(idReceta, idIngrediente);
                TempData["SuccessMessage"] = "Ingrediente agregado a la receta exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error al agregar ingrediente a la receta. Detalles: {ex.Message}";
            }
            return RedirectToAction("ViewByReceta", new { id = idReceta });
        }

        [HttpPost]
        public IActionResult EliminarIngredienteDeReceta(int idIngrediente, int idReceta)
        {
            try
            {
                _ingredienteDatos.EliminarIngredienteDeReceta(idIngrediente, idReceta);
                TempData["SuccessMessage"] = "Ingrediente eliminado de la receta exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error al eliminar ingrediente de la receta. Detalles: {ex.Message}";
            }
            return RedirectToAction("ViewByReceta", new { id = idReceta });
        }
    }
}