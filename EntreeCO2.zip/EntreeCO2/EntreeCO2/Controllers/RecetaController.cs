﻿using EntreeCO2.Data;
using EntreeCO2.Models;
using Microsoft.AspNetCore.Mvc;

namespace EntreeCO2.Controllers
{
    [Route("[controller]/[action]")]
    public class RecetaController : Controller
    {
        private readonly RecetaDatos _recetaDatos;

        public RecetaController(RecetaDatos recetaDatos)
        {
            _recetaDatos = recetaDatos;
        }

        public IActionResult Index()
        {
            var recetas = _recetaDatos.ListarRecetas();
            foreach (var receta in recetas) // Agrega esto para depuración
            {
                Console.WriteLine($"Receta ID: {receta.IdReceta}, Nombre: {receta.NombreReceta}");
            }
            return View(recetas);
        }

        [HttpGet("{id}")]
        public IActionResult Edit(int id)
        {
            var receta = _recetaDatos.ObtenerReceta(id);
            if (receta == null)
            {
                TempData["ErrorMessage"] = "Receta no encontrada.";
                return RedirectToAction("Index");
            }
            return View(receta);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit2(RecetaModel receta)
        {
            if (!ModelState.IsValid)
            {
                return View(receta);
            }
            try
            {
                _recetaDatos.ActualizarReceta(receta);
                TempData["SuccessMessage"] = "Receta actualizada exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error al actualizar la receta. Detalles: {ex.Message}";
            }
            return RedirectToAction("Index");
        }

        [HttpGet("{id}")]
        public IActionResult Delete(int id)
        {
            var receta = _recetaDatos.ObtenerReceta(id);
            if (receta == null)
            {
                TempData["ErrorMessage"] = "Receta no encontrada.";
                return RedirectToAction("Index");
            }
            return View(receta);
        }

        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                _recetaDatos.EliminarReceta(id);
                TempData["SuccessMessage"] = "Receta eliminada exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error al eliminar la receta. Detalles: {ex.Message}";
            }
            return RedirectToAction("Index");
        }

        [HttpGet("Add")]
        public IActionResult Add()
        {
            return View(new RecetaModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add2(RecetaModel receta)
        {
            if (!ModelState.IsValid)
            {
                return View("Add", receta);
            }
            try
            {
                _recetaDatos.InsertarReceta(receta.NombreReceta, receta.MetodoPreparacion, receta.IdRestaurante);
                TempData["SuccessMessage"] = "Receta agregada exitosamente.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error al agregar la receta. Detalles: {ex.Message}";
                return View("Add", receta);
            }
        }
    }
}