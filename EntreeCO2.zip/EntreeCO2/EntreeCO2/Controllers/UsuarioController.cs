﻿using Microsoft.AspNetCore.Mvc;
using EntreeCO2.Data;
using EntreeCO2.Models;
using Microsoft.AspNetCore.Authorization;
using System.Diagnostics;

namespace EntreeCO2.Controllers
{
    [Route("[controller]/[action]")]
    public class UsuariosController : Controller
    {
        private readonly UsuarioDatos _usuarioDatos;
        public UsuariosController()
        {
            _usuarioDatos = new UsuarioDatos();
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpGet("{id}")]
        public IActionResult GetUsuario(int id)
        {
            try
            {
                var usuario = _usuarioDatos.ObtenerUsuario(id);
                if (usuario == null)
                {
                    return NotFound();
                }
                return Ok(usuario);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error: " + ex.Message);
            }
        }

        [HttpPost("validar")]
        public IActionResult ValidarUsuario([FromForm] ValidacionUsuarioModel model)
        {
            try
            {
                bool resultado = _usuarioDatos.ValidarUsuario(model.Email, model.Contraseña);
                if (resultado)
                {
                    return RedirectToAction("Index", "Home");
                }
                return Unauthorized("Credenciales no válidas.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error: " + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult CrearUsuario([FromForm] UsuarioModel usuario)
        {
            try
            {
                _usuarioDatos.CrearUsuario(usuario);
                return RedirectToAction("Login");
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }
        }

    }
}