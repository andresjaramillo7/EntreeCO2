﻿using Microsoft.AspNetCore.Mvc;

public class JuegoController : Controller
{

    public IActionResult Game() // Si quieres usar "/Juego/Game"
    {
        return View(); // Esto buscará "Game.cshtml" en "/Views/Juego/"
    }
}
