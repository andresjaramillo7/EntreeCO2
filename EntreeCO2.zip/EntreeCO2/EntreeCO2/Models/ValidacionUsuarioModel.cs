﻿namespace EntreeCO2.Models
{
    public class ValidacionUsuarioModel
    {
        public string Email { get; set; }
        public string Contraseña { get; set; }
    }
}
