﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EntreeCO2.Models
{
    public class RecetaModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdReceta { get; set; }

        [Required(ErrorMessage = "El nombre de la receta es obligatorio.")]
        [StringLength(100, ErrorMessage = "El nombre de la receta no debe exceder los 100 caracteres.")]
        public string NombreReceta { get; set; }

        [Required(ErrorMessage = "El método de preparación es obligatorio.")]
        public string MetodoPreparacion { get; set; }

        [Display(Name = "Restaurante")]
        [Required(ErrorMessage = "Debe seleccionar un restaurante.")]
        public int IdRestaurante { get; set; }
        public List<IngredienteModel>? Ingredientes { get; set; }
    }
}