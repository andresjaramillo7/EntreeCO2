﻿namespace EntreeCO2.Models
{
    public class RecetaIngredienteModel
    {
        public int IdReceta { get; set; }
        public int IdIngrediente { get; set; }
    }

}
